<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class misviajes extends CI_Controller {

    function __construct() {
//grupo 65 gestion vm
        parent::__construct();


        $this->load->library('ion_auth');
        $this->load->library('form_validation');
        $this->load->helper('url');
        $this->load->model('estructura_model');
        $this->load->model('misviajes_model');

        //print_r($user);
        if ($this->ion_auth->logged_in() && ($this->ion_auth->in_group(2) ||
                $this->ion_auth->in_group(3) || $this->ion_auth->is_admin())) {
            // $this->login();
        } else {
            $this->session->set_flashdata('error', 'No tienes permiso para usar este componente');
            redirect();
        }
    }

    function index() {
        $data['template'] = 'misviajes/index';        
        $data['misviajes'] = $this->misviajes_model->get_viajes($this->ion_auth->user()->row()->username);
        $this->load->view('template/template', $data, false, true);
    }
    //desplegar la vista
    function actualizar_datos() {
        $id = $this->ion_auth->user()->row()->username;
        $datos['celular'] = $this->input->post('celular');
        $datos['email'] = $this->input->post('mail');
        print_r($datos);

        if ($this->misdatos_model->actualizar_datos_usuarios($datos, $id)) {                
                $data['mensaje'] = "Se ha realizado correctamente la remarcación!";
                $data['mensaje'] = $this->load->view('misdatos/modal_mensaje', $data, true);               

        } else {
            $data['mensaje'] = "Error actualizando, revise el código del asesor!";
            $data['mensaje'] = $this->load->view('misdatos/modal_mensaje', $data, true);
            $data['error'] = 0;
        }
        PRINT_R($data['mensaje']);
        echo json_encode($data);
    }

}

?>
