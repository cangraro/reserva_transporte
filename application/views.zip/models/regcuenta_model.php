<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class regcuenta_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function traer_activos_estructura() {
        $this->db->select('CEDULA as cedula,CODIGO_ASESOR_FENIX as codigo,CORREO_PORTAL as correo, NOMBRE_COMPLETO as nombre,CARGO');
        $this->db->where('ACTIVO', 1);
        $this->db->where('CORREO_PORTAL <>', '');
        $q = $this->db->get('jos_estructura_comercial');
        // echo $this->db->last_query();
        return $q->result();
    }

    function traer_inactivos_users() {
        $this->db->select('users.id');
        $this->db->where('ACTIVO', 0);
        $this->db->join('jos_estructura_comercial', 'jos_estructura_comercial.CODIGO_ASESOR_FENIX=users.username', 'inner');
        $q = $this->db->get('users');
        // echo $this->db->last_query();
        return $q->result();
    }

    function get_nombre($id) {
        /*$this->db->select('*');
        $r = new stdClass();
        $this->db->where('CODIGO_ASESOR_FENIX', $id);
        $q = $this->db->get('jos_estructura_comercial');
        if ($q->num_rows() == 0) {
            $r->NOMBRE_COMPLETO = $this->ion_auth->user()->row()->username;

            return $r;
        } else {
            return $q->row();
        }*/
        return true;
    }

    function get_codigo_fenix_jos_user($id) {
        $this->db->select('est.CARGO,est.CEDULA,est.NOMBRE_COMPLETO,est.CODIGO_CANAL_FENIX,est.CODIGO_ASESOR_FENIX,est.CORREO_PORTAL,est.CARGO');
        $this->db->where('est.CODIGO_ASESOR_FENIX', $id);
        $this->db->where('est.ACTIVO', 1, false);
        // $this->db->join('jos_estructura_comercial as est', 'est.CEDULA=jos_comprofiler.cb_cedula', 'left');
        $query = $this->db->get('jos_estructura_comercial as est');
        //log_message('debug', $this->db->last_query());
        //log_message('debug', 'correo:'.$query->row()->CORREO_PORTAL);
        //echo $this->db->last_query();
        if ($query->num_rows() == 0) {
            return false;
        } else {
            return $query->row();
        }
    }

    function validar_fecha($fecha_input) {
        //echo $fecha_input.'           ----   ';
        $fecha = explode('/', $fecha_input);
        // print_r($fecha);
        if (count($fecha) <= 1) {
            $fecha = explode('-', $fecha_input);
        }
        $data = false;
        $m = date('m');
        // print_r($fecha);
        //if(checkdate ( int $month , int $day , int $year ))
         if (checkdate($fecha[1], $fecha[0], $fecha[2])) {
            //col date
            if ($fecha[1] <= 12||$fecha[1] ==$m) {
                $data = "$fecha[2]-$fecha[1]-$fecha[0]";
            } else {
                $data = "$fecha[2]-$fecha[0]-$fecha[1]";
            }
        }
        if (checkdate($fecha[0], $fecha[1], $fecha[2])) {
            //usa date
            if ($fecha[0] <= 12||$fecha[0] ==$m) {
                $data = "$fecha[2]-$fecha[0]-$fecha[1]";
            } else {
                $data = "$fecha[2]-$fecha[1]-$fecha[0]";
            }
        }
       
        if (checkdate($fecha[1], $fecha[2], $fecha[0])) {
            //mysql date
            if ($fecha[1] <= 12||$fecha[1] ==$m) {
                $data = $fecha_input;
            } else {
                $data = "$fecha[0]-$fecha[2]-$fecha[1]";
            }
        }


        return $data;
    }

    function validar_fecha_mes($fecha_input) {
        //echo $fecha_input.'           ----   ';
        $fecha = explode('/', $fecha_input);
        // print_r($fecha);
        if (count($fecha) <= 1) {
            $fecha = explode('-', $fecha_input);
        }
        $m = date('m');
        $data = false;
        // print_r($fecha);
        //if(checkdate ( int $month , int $day , int $year ))
        if (checkdate($fecha[0], $fecha[1], $fecha[2])) {
            //usa date

            $data = "$fecha[2]-$fecha[0]-$fecha[1]";
        }
        if (checkdate($fecha[1], $fecha[0], $fecha[2])) {
            //col date
            $data = "$fecha[2]-$fecha[1]-$fecha[0]";
        }
        if (checkdate($fecha[1], $fecha[2], $fecha[0])) {
            //mysql date
            $data = $fecha_input;
        }
    }

     public function calcular_digito_nit($nit) {
        $primos = array(3, 7, 13, 17, 19, 23, 29, 37, 41, 43, 47, 53, 59, 67, 71);
        $temp = "";
        $suma = 0;
        $salida = "";
        // Hace un barrido por el NIT, desde el último dígito hasta el primero y luego multiplica cada dígito por el número primo
        // desde el primero hasta el último; es decir, último dígito del NIT * el primer número primo y así sucesivamente.
        // El resultado de tal producto lo va sumando
        for ($i = 0; $i < strlen($nit); $i++) {
            $temp = substr($nit, (strlen($nit) - 1) - $i, 1);
            $suma += (int) $temp * $primos[$i];
        }
        // A la suma anterior ser le haya el residuo de dividirlo por 11
        $residuo = $suma % 11;
        // Si el residuo es > 1, el dígito de verificación es la resta de 11 - residuo
        if ($residuo > 1) {
            $salida = 11 - $residuo;
        } else {
            $salida = $residuo;
        }
        return $salida;
    }
    
    
}
