<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class misviajes_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function get_viajes($id) {
        $fecha= date('Y') . '-' . date('m') . '-' . date('d');        
        //$fecha=$fecha->date;
        //print_r($fecha);
        $this->db->select('viaje.id_viaje,viaje.placa,vehiculo.capacidad-count(reserva.id_reserva) disponibles,viaje.horario,count(reserva.id_reserva) reservas,ruta.descripcion,ruta.mapa');
        $this->db->where('viaje.id_estado_viaje', 1);
        $this->db->where('reserva.id_estado_reserva', 1);
        $this->db->where('vehiculo.id_usuario', $id);
        $this->db->where('date(viaje.horario)', $fecha);
        $this->db->join('vehiculo','viaje.placa=vehiculo.placa','inner');
        $this->db->join('reserva','viaje.id_viaje=reserva.id_viaje','inner');
        $this->db->join('ruta','viaje.id_ruta=ruta.id_ruta','inner');        
        $this->db->group_by('viaje.id_viaje,viaje.placa,vehiculo.capacidad,viaje.horario,ruta.descripcion,ruta.mapa');
        $result = $this->db->get('viaje');
        //echo $this->db->last_query();
        //die;
        return $result->result();
    }
    
    
}
