

<div class="panel panel-default">
    <div class="panel-body">

        <div class="panel panel-info">
            <div class="panel-heading">
                <h2 class="text-center">Noticias y Tips</h2>
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-md-6">



                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3 class="panel-title"><?php echo $noticias[0]->titulo; ?></h3>
                            </div>
                            <div class="panel-body">
                                <div class="col-md-12">
                                    <?php echo $noticias[0]->contenido; ?>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-md-6">


                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <h3 class="panel-title"><?php echo $noticias[1]->titulo; ?></h3>
                            </div>
                            <div class="panel-body">
                                <div class="col-md-12">
                                    <?php echo $noticias[1]->contenido; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
