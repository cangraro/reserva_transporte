<div id="contenido_reserva" class="container-fluid">


    <div class="panel panel-default">
        <div class="panel-heading"><h2 class="text-center">Generar reserva</h2></div>



        <div class="panel-body">


            <div class="panel panel-default">
                <div class="panel-body">
                    <div id="motivos_cambio">
                        <label for="rutas">Rutas disponibles</label>
                        <select id="sel_rutas" name="sel_rutas" placeholder="Seleccione una ruta" class="form-control"  >
                            <option value="RutaA">Ruta Poblado</option>
                            <option value="RutaB">Ruta Robledo</option>
                            <option value="RutaC">Ruta Guayabal</option>
                            <option value="RutaD">Ruta Laureles</option>                            
                        </select>
                        <p></p>
                    </div>
                    <div class="col-md-4">
                        <div class="panel panel-default">
                            <div class="panel-heading">Ruta poblado</div>
                            <div class="panel-body">
                                <div class="row">                                
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="vehiculo">Vehiculo</label>
                                        </div>
                                        <div class="col-md-4">
                                            <p id="vehiculo">asd214</p>
                                        </div>
                                    </div>                                    
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="disponibilidad">Disponibilidad</label>
                                        </div>
                                        <div class="col-md-4">
                                            <p id="disponibilidad">28</p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="horario">Horario</label>
                                        </div>
                                        <div class="col-md-4">
                                            <p id="horario">7:00 AM</p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="seleccion"></label>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="radio-inline"><input type="radio" name="optradio">Seleccionar</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel panel-default">
                            <div class="panel-heading">Ruta poblado</div>
                            <div class="panel-body">
                                <div class="row">                                
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="vehiculo">Vehiculo</label>
                                        </div>
                                        <div class="col-md-4">
                                            <p id="vehiculo">asd214</p>
                                        </div>
                                    </div>                                    
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="disponibilidad">Disponibilidad</label>
                                        </div>
                                        <div class="col-md-4">
                                            <p id="disponibilidad">28</p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="horario">Horario</label>
                                        </div>
                                        <div class="col-md-4">
                                            <p id="horario">8:00 AM</p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="seleccion"></label>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="radio-inline"><input type="radio" name="optradio">Seleccionar</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button id="btn_reservar" type="button" class="btn btn-success navbar-btn" >Reservar</button>
                    </div>

<!--<iframe src="<?php // echo $source;            ?>" width="600" height="450" frameborder="0" style="border:0"></iframe>-->


                    <div class="col-lg-6">
                        <div class="panel panel-default">
                            <div class="panel-heading">Ruta Robledo</div>
                            <div class="panel-body">
                                <div class="embed-responsive embed-responsive-16by9">
                                    <iframe class="embed-responsive-item" src="https://www.google.com/maps/embed?pb=!1m20!1m8!1m3!1d7931.690501198279!2d-75.5766129648943!3d6.284063886660518!3m2!1i1024!2i768!4f13.1!4m9!3e0!4m3!3m2!1d6.2799368!2d-75.57856559999999!4m3!3m2!1d6.288873499999999!2d-75.57732109999999!5e0!3m2!1ses-419!2s!4v1433385935485" width="600" height="450" frameborder="0" style="border:0"></iframe>  
                                </div>

                            </div>
                        </div>
                    </div>
                    
                </div>

            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    $(function () {

        /*$("#boton_descargar").click(function() {
         
         var loader_ajax = "<div style=text-align:center><img src='<?php echo base_url(); ?>assets/images/loader.png'align='middle' /></div>";
         $("#descarga_contenido").html(loader_ajax);
         $("#descarga_contenido").fadeIn('fast');
         var dato_enviar = {
         mes: $('#drop_visitas_mes').val(),
         anio: $('#drop_visitas_anio').val()};
         //////console.log(dato_enviar);
         
         
         var url = "<?php echo base_url(); ?>restruthor/index";
         $.ajax({
         async: 'False',
         type: 'POST',
         dataType: 'html',
         url: url,
         data: dato_enviar,
         success: function(data) {
         $("#descarga_contenido").fadeOut('fast', function() {
         $("#descarga_contenido").html(data);
         $("#descarga_contenido").fadeIn('fast');
         });
         },
         statusCode: {
         500: function() {
         $("#descarga_contenido").fadeOut('fast', function() {
         $("#descarga_contenido").html("<h1>Error de Interno! si el problema persiste favor informar al administrador</h1>");
         $("#descarga_contenido").fadeIn('fast');
         });
         },
         502: function() {
         $("#descarga_contenido").fadeOut('fast', function() {
         $("#descarga_contenido").html("<h1>Error de conexion por favor intentar en unos segundos</h1>");
         $("#descarga_contenido").fadeIn('fast');
         });
         }
         }
         });
         return false;
         });*/

    });
</script>
