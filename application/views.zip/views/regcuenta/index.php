<div id="contenido_reserva" class="container-fluid">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h2 class="text-center">Mi Datos</h2>
        </div>
        <div class="panel-body">

            <div class="col-md-5">

                <div  class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Datos Conductor</h3>
                    </div>
                    <div class="panel-body">

                        <div class="row">

                            <div class="row">
                                <div class="col-md-4">
                                    <label for="nombre">Cedula :</label>
                                </div>
                                <div class="col-md-5">
                                    <p id="cedula">1044******</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="nombre">Conductor :</label>
                                </div>
                                <div class="col-md-5">
                                    <p for="vehiculo">Alberto Chacon</p>
                                </div>
                            </div>                                
                            <div class="row">
                                <div class="col-md-4">
                                    <p id="empresa"></p>
                                </div>
                                <div class="col-md-5">
                                    <p id="empresa"></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Datos Vehiculo</h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="nombre">Placa :</label>
                                </div>
                                <div class="col-md-5">
                                    <p id="placa">RTV413</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="nombre">Tipo :</label>
                                </div>
                                <div class="col-md-5">
                                    <p id="vehiculo">Minivan</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="nombre">Matricula :</label>
                                </div>
                                <div class="col-md-5">
                                    <p id="vehiculo">57785487</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="tecnico">Tecnicomecanica :</label>
                                </div>
                                <div class="col-md-5">
                                    <p id="tecnico">12/12/2016</p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="empresa">Empresa afiliada</label>
                                </div>
                                <div class="col-md-5">
                                    <p id="empresa" >Transportamos</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-md-5">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Datos Actualizar</h3>
                    </div>
                    <div class="panel-body">
                        <div class="row">
                            <div class="row">
                                <div class="col-md-2">
                                    <label for="celular">Celular:</label>
                                </div>
                                <div class="col-md-5">
                                    <input id="celular" type="text" class="form-control" value="3000000000">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-2">
                                    <label for="celular">Email:</label>
                                </div>
                                <div class="col-md-5">
                                    <input id="mail" type="email" class="form-control" value="alberto.chacon@gmail.com">
                                </div>
                            </div>                                

                        </div>
                    </div>

                </div>
                <div>                        
                    <button id="btn_actualizar" type="button" class="btn btn-success navbar-btn" >Actualizar</button>
                </div>
            </div>





        </div>
    </div>
</div>

<script type="text/javascript">
    $(function () {
        bootbox.confirm("Are you sure?", function (result) {
            Example.show("Confirm result: " + result);
        });

    }
    /*$("#boton_descargar").click(function() {
     
     var loader_ajax = "<div style=text-align:center><img src='<?php echo base_url(); ?>assets/images/loader.png'align='middle' /></div>";
     $("#descarga_contenido").html(loader_ajax);
     $("#descarga_contenido").fadeIn('fast');
     var dato_enviar = {
     mes: $('#drop_visitas_mes').val(),
     anio: $('#drop_visitas_anio').val()};
     //////console.log(dato_enviar);
     
     
     var url = "<?php echo base_url(); ?>restruthor/index";
     $.ajax({
     async: 'False',
     type: 'POST',
     dataType: 'html',
     url: url,
     data: dato_enviar,
     success: function(data) {
     $("#descarga_contenido").fadeOut('fast', function() {
     $("#descarga_contenido").html(data);
     $("#descarga_contenido").fadeIn('fast');
     });
     },
     statusCode: {
     500: function() {
     $("#descarga_contenido").fadeOut('fast', function() {
     $("#descarga_contenido").html("<h1>Error de Interno! si el problema persiste favor informar al administrador</h1>");
     $("#descarga_contenido").fadeIn('fast');
     });
     },
     502: function() {
     $("#descarga_contenido").fadeOut('fast', function() {
     $("#descarga_contenido").html("<h1>Error de conexion por favor intentar en unos segundos</h1>");
     $("#descarga_contenido").fadeIn('fast');
     });
     }
     }
     });
     return false;
     });*/

    });
</script>
