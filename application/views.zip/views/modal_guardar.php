<div id="info_mensaje">
    <p></p>
    <h3 class="text-center"><?php echo $mensaje; ?></h3>
</div>









