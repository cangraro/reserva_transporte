

<script>
    $(document).ready(function() {
        if("<?php echo $this->session->flashdata('message')?>" != ''){
           // alert("<?php echo $this->session->flashdata('message')?>");
        }
        
       // $(document).foundation();
    });

</script>
</body>
<div class="footer">
    <div class="container">
        <p></p>
        <p class="text-center">Desarrollado Por Jhonathan Monsalve y Eider Barrientos</p>
    </div>
</div>

