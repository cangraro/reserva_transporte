<div id="contenido_reserva" class="container-fluid">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h2 class="text-center">Registro usuarios</h2>
        </div>
        <div class="panel-body">

            <div class="col-md-5">

                <div  class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Datos Usuario</h3>
                    </div>
                    <div class="panel-body">

                        <div class="row">

                            <div class="row">
                                <div class="col-md-4">
                                    <label for="nombre">Cedula :</label>
                                </div>
                                <div class="col-md-5">
                                    <input id="cedula" type="text" class="form-control" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="nombre">Nombre :</label>
                                </div>
                                <div class="col-md-5">
                                    <input id="nombre" type="text" class="form-control" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="fecha_nacimiento">Fecha de nacimiento :</label>
                                </div>
                                <div class="col-md-5">
                                    <input id="fecha_nacimiento" type="date" class="form-control" max="1995-12-31" min="1950-01-01" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="telefono">Telefono :</label>
                                </div>
                                <div class="col-md-5">
                                    <input id="telefono" type="text" class="form-control" required>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="celular">Celular:</label>
                                </div>
                                <div class="col-md-5">
                                    <input id="Celular" type="text" class="form-control" required> 
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="tipo">Perfil:</label>
                                </div>
                                <div class="col-md-5">
                                    <select id="tipo" type="text" class="form-control" required> 
                                        <option value="">--Seleccione uno--</option>
                                        <option value="estudiante">Estudiante</option>
                                        <option value="conductor">Conductor</option>                                  
                                    </select>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>                
                <div>                        
                    <button id="btn_actualizar" type="button" class="btn btn-success navbar-btn" >Actualizar</button>
                </div>
            </div>





        </div>
    </div>
</div>

<script type="text/javascript">
    $(function () {
        bootbox.confirm("Are you sure?", function (result) {
            Example.show("Confirm result: " + result);
        });

    }
    /*$("#boton_descargar").click(function() {
     
     var loader_ajax = "<div style=text-align:center><img src='<?php echo base_url(); ?>assets/images/loader.png'align='middle' /></div>";
     $("#descarga_contenido").html(loader_ajax);
     $("#descarga_contenido").fadeIn('fast');
     var dato_enviar = {
     mes: $('#drop_visitas_mes').val(),
     anio: $('#drop_visitas_anio').val()};
     //////console.log(dato_enviar);
     
     
     var url = "<?php echo base_url(); ?>restruthor/index";
     $.ajax({
     async: 'False',
     type: 'POST',
     dataType: 'html',
     url: url,
     data: dato_enviar,
     success: function(data) {
     $("#descarga_contenido").fadeOut('fast', function() {
     $("#descarga_contenido").html(data);
     $("#descarga_contenido").fadeIn('fast');
     });
     },
     statusCode: {
     500: function() {
     $("#descarga_contenido").fadeOut('fast', function() {
     $("#descarga_contenido").html("<h1>Error de Interno! si el problema persiste favor informar al administrador</h1>");
     $("#descarga_contenido").fadeIn('fast');
     });
     },
     502: function() {
     $("#descarga_contenido").fadeOut('fast', function() {
     $("#descarga_contenido").html("<h1>Error de conexion por favor intentar en unos segundos</h1>");
     $("#descarga_contenido").fadeIn('fast');
     });
     }
     }
     });
     return false;
     });*/

    });
</script>
