<div id="contenido_reserva" class="container-fluid">
    <div class="panel panel-default">
        <div class="panel-heading">
            <h2 class="text-center">Gestor rutas</h2>
        </div>
        <div class="panel-body">

            <div class="col-md-5">

                <div  class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Datos Ruta</h3>
                    </div>
                    <div class="panel-body">

                        <div class="row">

                            <div class="row">
                                <div class="col-md-4">
                                    <label for="nombre">Placa :</label>
                                </div>
                                <div class="col-md-5">
                                    <select id="tipo" type="text" class="form-control" required> 
                                        <option value="">--Seleccione uno--</option>
                                        <option value="1">ABC123</option>
                                        <option value="2">DEF456</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="tipo">Ruta:</label>
                                </div>
                                <div class="col-md-5">
                                    <select id="tipo" type="text" class="form-control" required> 
                                        <option value="">--Seleccione uno--</option>
                                        <option value="1">Ruta Ida</option>
                                        <option value="2">Ruta Vuelta</option>
                                    </select>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="fecha">Horario :</label>
                                </div>
                                <div class="col-md-5">
                                     <input  id="fecha" type="datetime-local" min="<?php echo date('Y') . '-' . date('m') . '-' . date('d') . 'T05:00:00.00'; ?>"  name="fecha" class="form-control" required />
                                </div>
                            </div>

                        </div>
                    </div>
                </div>                
                <div>                        
                    <button id="btn_actualizar" type="button" class="btn btn-success navbar-btn" >Guardar</button>
                </div>
            </div>





        </div>
    </div>
</div>

<script type="text/javascript">
    $(function () {
        bootbox.confirm("Are you sure?", function (result) {
            Example.show("Confirm result: " + result);
        });

    }
    /*$("#boton_descargar").click(function() {
     
     var loader_ajax = "<div style=text-align:center><img src='<?php echo base_url(); ?>assets/images/loader.png'align='middle' /></div>";
     $("#descarga_contenido").html(loader_ajax);
     $("#descarga_contenido").fadeIn('fast');
     var dato_enviar = {
     mes: $('#drop_visitas_mes').val(),
     anio: $('#drop_visitas_anio').val()};
     //////console.log(dato_enviar);
     
     
     var url = "<?php echo base_url(); ?>restruthor/index";
     $.ajax({
     async: 'False',
     type: 'POST',
     dataType: 'html',
     url: url,
     data: dato_enviar,
     success: function(data) {
     $("#descarga_contenido").fadeOut('fast', function() {
     $("#descarga_contenido").html(data);
     $("#descarga_contenido").fadeIn('fast');
     });
     },
     statusCode: {
     500: function() {
     $("#descarga_contenido").fadeOut('fast', function() {
     $("#descarga_contenido").html("<h1>Error de Interno! si el problema persiste favor informar al administrador</h1>");
     $("#descarga_contenido").fadeIn('fast');
     });
     },
     502: function() {
     $("#descarga_contenido").fadeOut('fast', function() {
     $("#descarga_contenido").html("<h1>Error de conexion por favor intentar en unos segundos</h1>");
     $("#descarga_contenido").fadeIn('fast');
     });
     }
     }
     });
     return false;
     });*/

    });
</script>
