<div id="contenido_reserva" class="container-fluid">


    <div class="panel panel-default">
        <div class="panel-heading"><h2 class="text-center">Mis viajes</h2></div>
        <div class="panel-body">            
            <div class="col-md-4">
                <?php foreach($misviajes as $miviaje ) {?>
                <div class="panel panel-default">
                    <div class="panel-heading"><?php echo $miviaje->descripcion; ?></div>
                    <div class="panel-body">
                        <div class="row">                                
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="vehiculo">Vehiculo</label>
                                </div>
                                <div class="col-md-4">
                                    <p id="vehiculo"><?php echo $miviaje->placa; ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="reservados">Reservados</label>
                                </div>
                                <div class="col-md-4">
                                    <p id="reservados"><?php echo $miviaje->reservas; ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="disponibilidad">Disponibilidad</label>
                                </div>
                                <div class="col-md-4">
                                    <p id="disponibilidad"><?php echo $miviaje->disponibles; ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="horario">Horario</label>
                                </div>
                                <div class="col-md-4">
                                    <p id="horario"><?php echo $miviaje->horario; ?></p>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <label for="seleccion"></label>
                                </div>
                                <div class="col-md-4">
                                    <label class="radio-inline" id="<?php echo $miviaje->id_viaje; ?>"><input type="radio" name="<?php echo $miviaje->id_viaje; ?>">Seleccionar</label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php }?>                
                <button id="btn_encurso" type="button" class="btn btn-success navbar-btn" >En curso</button>
                <button id="btn_cancelar" type="button" class="btn btn-danger navbar-btn" >Cancelar</button>
            </div>
            <div class="col-lg-6">
                <div class="panel panel-default">
                    <div class="panel-heading"><?php echo $miviaje->descripcion; ?></div>
                    <div class="panel-body">
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe class="embed-responsive-item" src="<?php echo $miviaje->mapa; ?>" width="600" height="450" frameborder="0" style="border:0"></iframe>  
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>

</div>

<script type="text/javascript">
    $(function () {

        

    });
</script>
